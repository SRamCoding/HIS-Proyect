<!--
  Campos del formulario de Grupo Ocupacional, compartidos entre
  create.vue y [id].vue. `form` y `errors` son los mismos objetos
  reactive() del padre: los mutamos directo (igual que en tus
  vistas originales), así evitamos v-model anidado con emits extra.
-->
<template>
  <div class="form-grid">
    <FormField
      :model-value="form.nombre"
      label="Nombre"
      required
      icon="i-heroicons-user-group"
      placeholder="Ej: Profesionales de la Salud, Técnicos Asistenciales"
      hint="Nombre descriptivo del grupo ocupacional"
      :error="errors.nombre"
      full-width
      @update:model-value="form.nombre = $event"
      @focus="errors.nombre = ''"
    />

    <FormField
      :model-value="form.codigo"
      label="Código"
      icon="i-heroicons-barcode"
      placeholder="Ej: GRP-001"
      hint="Código de referencia interno"
      mono
      @update:model-value="form.codigo = $event"
    />

    <div class="form-group">
      <label class="form-label">Estado</label>
      <StatusToggle
        :model-value="form.is_active"
        label="Grupo Activo"
        @update:model-value="form.is_active = $event"
      />
      <p class="field-hint">Los grupos inactivos no estarán disponibles</p>
    </div>

    <FormField
      :model-value="form.descripcion"
      label="Descripción"
      as="textarea"
      icon="i-heroicons-document-text"
      placeholder="Descripción del grupo ocupacional..."
      full-width
      @update:model-value="form.descripcion = $event"
    />

    <PreviewCard
      v-if="showPreview"
      class="form-group full-width"
      icon="i-heroicons-user-group"
      :name="form.nombre"
      :code="form.codigo"
      :description="form.descripcion"
      :active="form.is_active"
    />
  </div>
</template>

<script setup lang="ts">
defineProps<{
  form: { nombre: string; codigo: string; descripcion: string; is_active: boolean }
  errors: { nombre: string }
  showPreview?: boolean
}>()
</script>
