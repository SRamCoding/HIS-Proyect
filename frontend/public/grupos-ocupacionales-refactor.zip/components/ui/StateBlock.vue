<template>
  <div class="state-block">
    <div v-if="type === 'loading'" class="spin">
      <UIcon name="i-heroicons-arrow-path" class="w-8 h-8" style="color: var(--teal)" />
    </div>
    <UIcon
      v-else-if="type === 'error'"
      name="i-heroicons-exclamation-triangle"
      class="w-8 h-8"
      style="color: var(--alert)"
    />
    <div v-else class="state-icon-circle">
      <UIcon :name="icon || 'i-heroicons-inbox'" class="w-12 h-12" style="color: var(--ink-soft)" />
    </div>
    <h3 v-if="title" style="color: var(--ink); font-size: 1.125rem; margin: 0">{{ title }}</h3>
    <p v-if="message" :style="{ color: type === 'error' ? 'var(--alert)' : 'var(--ink-soft)' }">
      {{ message }}
    </p>
    <slot />
  </div>
</template>

<script setup lang="ts">
defineProps<{ type: 'loading' | 'error' | 'empty'; title?: string; message?: string; icon?: string }>()
</script>
