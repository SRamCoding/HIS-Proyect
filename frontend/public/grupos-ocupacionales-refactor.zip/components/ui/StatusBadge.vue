<template>
  <span
    class="status-pill"
    :class="[variant === 'table' ? 'status-pill--table' : '', active ? 'is-on' : 'is-off']"
  >
    <span
      class="status-dot"
      :class="[variant === 'table' ? 'status-dot--table' : '', active ? 'is-on' : 'is-off']"
    />
    {{ active ? activeLabel : inactiveLabel }}
  </span>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{
    active: boolean
    variant?: 'table' | 'mini'
    activeLabel?: string
    inactiveLabel?: string
  }>(),
  { variant: 'mini', activeLabel: 'Activo', inactiveLabel: 'Inactivo' }
)
</script>
