<template>
  <template v-for="(item, i) in items" :key="i">
    <div class="summary-item">
      <span class="summary-label">{{ item.label }}</span>
      <span class="summary-value" :class="{ 'font-mono-data': item.mono }">
        <slot v-if="item.slot" :name="item.slot" />
        <template v-else>{{ item.value || '—' }}</template>
      </span>
    </div>
    <div v-if="item.divider" class="summary-divider" />
  </template>
</template>

<script setup lang="ts">
defineProps<{
  items: { label: string; value?: string; mono?: boolean; divider?: boolean; slot?: string }[]
}>()
</script>
