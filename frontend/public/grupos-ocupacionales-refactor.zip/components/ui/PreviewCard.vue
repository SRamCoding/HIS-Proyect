<template>
  <div class="preview-section">
    <h4 class="preview-title">Vista Previa</h4>
    <div class="preview-card">
      <IconBadge
        :icon="icon"
        size="sm"
        :bg="active ? 'var(--ok-soft)' : 'var(--mist)'"
        :color="active ? 'var(--ok)' : 'var(--ink-soft)'"
      />
      <div class="preview-info">
        <span class="preview-name">{{ name || namePlaceholder }}</span>
        <span class="preview-detail">
          <span class="preview-code">{{ code || 'Sin código' }}</span>
          <span>{{ description || 'Sin descripción' }}</span>
        </span>
      </div>
      <StatusBadge :active="active" />
    </div>
  </div>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{
    icon: string
    name?: string
    code?: string
    description?: string
    active: boolean
    namePlaceholder?: string
  }>(),
  { namePlaceholder: 'Nombre' }
)
</script>
