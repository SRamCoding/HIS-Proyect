<template>
  <div class="stat-card" :style="{ borderLeft: `4px solid ${accent}` }">
    <IconBadge :icon="icon" size="sm" :bg="bg" :color="accent" />
    <div style="display: flex; flex-direction: column">
      <span class="stat-card-value">{{ value }}</span>
      <span class="stat-card-label">{{ label }}</span>
    </div>
  </div>
</template>

<script setup lang="ts">
defineProps<{ icon: string; value: number | string; label: string; accent: string; bg: string }>()
</script>
