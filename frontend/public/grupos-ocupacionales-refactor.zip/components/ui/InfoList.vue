<template>
  <ul class="info-list">
    <li v-for="(item, i) in items" :key="i" class="info-item">
      <UIcon name="i-heroicons-check-circle" class="info-item-icon" style="color: var(--teal)" />
      <span>{{ item }}</span>
    </li>
  </ul>
</template>

<script setup lang="ts">
defineProps<{ items: string[] }>()
</script>
