<template>
  <div class="status-toggle">
    <span class="toggle-label">{{ label }}</span>
    <button
      type="button"
      role="switch"
      :aria-checked="modelValue"
      class="toggle-switch"
      :class="{ 'is-active': modelValue }"
      @click="$emit('update:modelValue', !modelValue)"
    >
      <span class="toggle-slider" />
    </button>
  </div>
</template>

<script setup lang="ts">
withDefaults(defineProps<{ modelValue: boolean; label?: string }>(), { label: 'Activo' })
defineEmits<{ 'update:modelValue': [value: boolean] }>()
</script>
