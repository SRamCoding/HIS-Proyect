<template>
  <div class="icon-badge" :class="sizeClass" :style="{ background: bg }">
    <UIcon :name="icon" :class="iconSizeClass" :style="{ color }" />
  </div>
</template>

<script setup lang="ts">
const props = withDefaults(
  defineProps<{
    icon: string
    bg?: string
    color?: string
    size?: 'lg' | 'sm' | 'xs'
  }>(),
  { bg: 'var(--mist)', color: 'var(--ink-soft)', size: 'lg' }
)

const sizeClass = computed(() =>
  props.size === 'sm' ? 'icon-badge--sm' : props.size === 'xs' ? 'icon-badge--xs' : ''
)
const iconSizeClass = computed(() => (props.size === 'lg' ? 'w-6 h-6' : 'w-4 h-4'))
</script>
