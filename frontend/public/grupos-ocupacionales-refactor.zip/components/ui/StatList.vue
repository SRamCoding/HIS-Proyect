<template>
  <div v-for="(item, i) in items" :key="i" class="stat-row">
    <span class="stat-row-label">{{ item.label }}</span>
    <span class="stat-row-value" :style="{ color: item.color }">{{ item.value }}</span>
  </div>
</template>

<script setup lang="ts">
defineProps<{ items: { label: string; value: string; color?: string }[] }>()
</script>
