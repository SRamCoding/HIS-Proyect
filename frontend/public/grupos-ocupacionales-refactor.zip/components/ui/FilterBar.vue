<template>
  <div class="filter-bar">
    <div class="filter-left">
      <div class="search-wrap">
        <UIcon name="i-heroicons-magnifying-glass" class="search-icon" />
        <input
          :value="search"
          type="text"
          :placeholder="placeholder"
          class="search-input"
          @input="$emit('update:search', ($event.target as HTMLInputElement).value)"
        />
      </div>
      <div class="filter-chips">
        <button
          v-for="f in filters"
          :key="f.value"
          class="filter-chip"
          :class="{ 'is-active': modelValue === f.value }"
          @click="$emit('update:modelValue', f.value)"
        >
          {{ f.label }}
          <span class="filter-chip-count">{{ f.count }}</span>
        </button>
      </div>
    </div>
    <div class="filter-right">
      <span class="result-count">{{ resultCount }} resultados</span>
      <button v-if="showReset" class="btn-secondary btn-sm" @click="$emit('reset')">
        <UIcon name="i-heroicons-arrow-path" class="w-3.5 h-3.5" />
        Resetear
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
defineProps<{
  search: string
  modelValue: string
  filters: { label: string; value: string; count: number }[]
  resultCount: number
  showReset: boolean
  placeholder?: string
}>()
defineEmits<{
  'update:search': [value: string]
  'update:modelValue': [value: string]
  reset: []
}>()
</script>
