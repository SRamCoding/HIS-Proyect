<template>
  <div class="widget" :class="{ 'widget--tip': tip }">
    <div v-if="!tip" class="widget-header">
      <UIcon :name="icon" class="widget-icon" :style="{ color: iconColor }" />
      <h4 class="widget-title">{{ title }}</h4>
    </div>
    <div class="widget-content">
      <slot />
    </div>
  </div>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{ icon?: string; title?: string; iconColor?: string; tip?: boolean }>(),
  { iconColor: 'var(--teal)' }
)
</script>
