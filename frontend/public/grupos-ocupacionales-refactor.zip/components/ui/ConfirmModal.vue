<template>
  <div v-if="modelValue" class="modal-overlay" @click.self="$emit('update:modelValue', false)">
    <div class="modal-content">
      <div class="modal-header">
        <IconBadge icon="i-heroicons-exclamation-triangle" size="sm" bg="var(--alert-soft)" color="var(--alert)" />
        <h3 class="modal-title">{{ title }}</h3>
      </div>
      <p class="modal-body">
        <slot />
      </p>
      <div class="modal-footer">
        <button class="btn-secondary" @click="$emit('update:modelValue', false)">Cancelar</button>
        <button class="btn-danger" @click="$emit('confirm')">
          <UIcon name="i-heroicons-trash" class="w-4 h-4" />
          {{ confirmLabel }}
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{ modelValue: boolean; title?: string; confirmLabel?: string }>(),
  { title: 'Confirmar Eliminación', confirmLabel: 'Eliminar' }
)
defineEmits<{ 'update:modelValue': [value: boolean]; confirm: [] }>()
</script>
