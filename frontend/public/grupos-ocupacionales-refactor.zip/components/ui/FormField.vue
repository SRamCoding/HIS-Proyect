<template>
  <div class="form-group" :class="{ 'full-width': fullWidth }">
    <label class="form-label">{{ label }} <span v-if="required" class="required">*</span></label>
    <div class="input-wrap">
      <UIcon
        v-if="icon"
        :name="icon"
        class="input-wrap-icon"
        :class="{ 'input-wrap-icon--top': as === 'textarea' }"
      />
      <textarea
        v-if="as === 'textarea'"
        class="input-clinical"
        :class="{ 'input-clinical--icon': icon, 'input-error': error }"
        :rows="rows"
        :placeholder="placeholder"
        :value="modelValue"
        @input="$emit('update:modelValue', ($event.target as HTMLTextAreaElement).value)"
      />
      <input
        v-else
        :type="type"
        class="input-clinical"
        :class="{ 'input-clinical--icon': icon, 'input-error': error, 'font-mono-data': mono }"
        :placeholder="placeholder"
        :value="modelValue"
        @input="$emit('update:modelValue', ($event.target as HTMLInputElement).value)"
        @focus="$emit('focus')"
      />
    </div>
    <span v-if="error" class="field-error">{{ error }}</span>
    <p v-if="hint" class="field-hint">{{ hint }}</p>
  </div>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{
    modelValue: string
    label: string
    icon?: string
    placeholder?: string
    hint?: string
    error?: string
    required?: boolean
    fullWidth?: boolean
    as?: 'input' | 'textarea'
    type?: string
    rows?: number
    mono?: boolean
  }>(),
  { as: 'input', type: 'text', rows: 3 }
)
defineEmits<{ 'update:modelValue': [value: string]; focus: [] }>()
</script>
