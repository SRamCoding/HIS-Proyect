<template>
  <SidebarWidget tip>
    <div class="tip-content">
      <UIcon name="i-heroicons-light-bulb" class="tip-icon" style="color: var(--warn)" />
      <div>
        <p class="tip-title">Consejo</p>
        <p class="tip-text"><slot /></p>
      </div>
    </div>
  </SidebarWidget>
</template>
