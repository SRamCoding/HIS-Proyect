<template>
  <div class="layout-with-sidebar">
    <div class="layout-grid">
      <div class="layout-main">
        <div class="mb-8">
          <nav class="breadcrumb">
            <NuxtLink :to="`/sigarh/mantenimiento/grupos-ocupacionales?tenant=${tenantId}`">
              <UIcon name="i-heroicons-user-group" class="w-3.5 h-3.5" />
              Grupos Ocupacionales
            </NuxtLink>
            <UIcon name="i-heroicons-chevron-right" class="w-3 h-3" />
            <span class="breadcrumb-current">Nuevo Grupo</span>
          </nav>
          <div class="flex items-center gap-4">
            <IconBadge icon="i-heroicons-plus-circle" bg="var(--ok-soft)" color="var(--ok)" />
            <div>
              <h1 class="page-head-title">Crear Grupo Ocupacional</h1>
              <p class="page-head-subtitle">Define un nuevo grupo ocupacional para el personal</p>
            </div>
          </div>
        </div>

        <section class="panel-card">
          <div class="panel-card-header">
            <IconBadge icon="i-heroicons-cog-6-tooth" size="sm" bg="var(--ok-soft)" color="var(--ok)" />
            <div>
              <h3 class="panel-card-title">Configuración del Grupo Ocupacional</h3>
              <p class="panel-card-subtitle">Ingresa los datos del nuevo grupo ocupacional</p>
            </div>
          </div>

          <div v-if="error" class="banner-error">
            <UIcon name="i-heroicons-exclamation-triangle" class="w-4 h-4 shrink-0" />
            {{ error }}
          </div>

          <GrupoOcupacionalForm :form="form" :errors="errors" :show-preview="!!(form.nombre || form.codigo)" />

          <div class="form-actions">
            <div class="action-group">
              <button class="btn-primary" :disabled="saving" @click="handleCreate(false)">
                <UIcon v-if="saving" name="i-heroicons-arrow-path" class="w-4 h-4 animate-spin" />
                <UIcon v-else name="i-heroicons-check" class="w-4 h-4" />
                {{ saving ? 'Creando...' : 'Crear Grupo' }}
              </button>
              <button class="btn-outline" :disabled="saving" @click="handleCreate(true)">
                <UIcon name="i-heroicons-plus" class="w-4 h-4" />
                Crear y otro
              </button>
              <NuxtLink :to="`/sigarh/mantenimiento/grupos-ocupacionales?tenant=${tenantId}`" class="btn-cancel">
                Cancelar
              </NuxtLink>
            </div>
          </div>
        </section>
      </div>

      <div class="layout-sidebar">
        <SidebarWidget icon="i-heroicons-information-circle" title="Información" icon-color="var(--teal)">
          <InfoList :items="infoItems" />
        </SidebarWidget>

        <SidebarWidget icon="i-heroicons-document-text" title="Resumen" icon-color="var(--ok)">
          <SummaryList :items="summaryItems">
            <template #estado>
              <StatusBadge :active="form.is_active" />
            </template>
          </SummaryList>
        </SidebarWidget>

        <TipWidget>
          Define grupos ocupacionales claros que reflejen las diferentes categorías de personal en el hospital.
        </TipWidget>

        <SidebarWidget icon="i-heroicons-chart-bar" title="Estado del Formulario" icon-color="var(--purple)">
          <StatList :items="statItems" />
        </SidebarWidget>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
definePageMeta({ layout: 'sigarh', middleware: ['auth'] })

const { api } = useApi()
const route = useRoute()
const router = useRouter()

const tenantId = computed(() => (route.query.tenant as string) || '')
const saving = ref(false)
const error = ref('')

const errors = reactive({ nombre: '' })
const form = reactive({ nombre: '', codigo: '', descripcion: '', is_active: true })

const filledFields = computed(() => [form.nombre, form.codigo, form.descripcion].filter(Boolean).length)

const infoItems = [
  'Los grupos ocupacionales clasifican al personal',
  'Se utilizan en la configuración de guardias y permisos',
  'El código interno ayuda a identificar rápidamente',
  'Los grupos inactivos no se pueden asignar',
]

const truncate = (s: string, n: number) => (s ? (s.length > n ? s.slice(0, n) + '...' : s) : '')

const summaryItems = computed(() => [
  { label: 'Nombre', value: form.nombre },
  { label: 'Código', value: form.codigo, mono: true, divider: true },
  { label: 'Descripción', value: truncate(form.descripcion, 50), divider: true },
  { label: 'Estado', slot: 'estado' },
])

const statItems = computed(() => [
  { label: 'Campos completos', value: `${filledFields.value}/3` },
  { label: 'Código', value: form.codigo ? '✓ Asignado' : '—', color: form.codigo ? 'var(--teal)' : 'var(--ink-soft)' },
  { label: 'Estado', value: form.is_active ? 'Activo' : 'Inactivo', color: form.is_active ? 'var(--ok)' : 'var(--ink-soft)' },
])

const validateForm = (): boolean => {
  let valid = true
  if (!form.nombre.trim()) {
    errors.nombre = 'El nombre del grupo ocupacional es requerido'
    valid = false
  }
  return valid
}

const handleCreate = async (createAnother: boolean) => {
  if (!validateForm()) return

  saving.value = true
  error.value = ''
  try {
    await api('/sigarh/mantenimiento/grupos-ocupacionales', {
      method: 'POST',
      body: {
        nombre: form.nombre,
        codigo: form.codigo || null,
        descripcion: form.descripcion || null,
        is_active: form.is_active,
      },
    })

    if (createAnother) {
      Object.assign(form, { nombre: '', codigo: '', descripcion: '', is_active: true })
      errors.nombre = ''
    } else {
      router.push(`/sigarh/mantenimiento/grupos-ocupacionales?tenant=${tenantId.value}`)
    }
  } catch (e: any) {
    error.value = e?.data?.detail || 'No se pudo crear el grupo ocupacional'
  } finally {
    saving.value = false
  }
}
</script>
