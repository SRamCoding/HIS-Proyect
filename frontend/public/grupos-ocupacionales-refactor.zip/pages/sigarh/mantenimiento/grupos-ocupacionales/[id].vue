<template>
  <div class="layout-with-sidebar">
    <div class="layout-grid">
      <div class="layout-main">
        <div class="mb-8">
          <nav class="breadcrumb">
            <NuxtLink :to="`/sigarh/mantenimiento/grupos-ocupacionales?tenant=${tenantId}`">
              <UIcon name="i-heroicons-user-group" class="w-3.5 h-3.5" />
              Grupos Ocupacionales
            </NuxtLink>
            <UIcon name="i-heroicons-chevron-right" class="w-3 h-3" />
            <span class="breadcrumb-current">Editar Grupo</span>
          </nav>
          <div class="flex items-center gap-4">
            <IconBadge
              icon="i-heroicons-user-group"
              :bg="form.is_active ? 'var(--ok-soft)' : 'var(--mist)'"
              :color="form.is_active ? 'var(--ok)' : 'var(--ink-soft)'"
            />
            <div>
              <h1 class="page-head-title">{{ form.nombre || 'Editar Grupo Ocupacional' }}</h1>
              <p class="page-head-subtitle" style="display: flex; align-items: center; gap: 0.5rem">
                <span class="font-mono-data">{{ form.codigo ? `Código: ${form.codigo}` : 'Sin código' }}</span>
                <span class="status-dot" :class="form.is_active ? 'is-on' : 'is-off'" />
                <span :style="{ color: form.is_active ? 'var(--ok)' : 'var(--ink-soft)', fontWeight: 500, fontSize: '0.75rem' }">
                  {{ form.is_active ? 'Activo' : 'Inactivo' }}
                </span>
              </p>
            </div>
          </div>
        </div>

        <StateBlock v-if="loading" type="loading" message="Cargando información del grupo..." class="panel-card" />

        <template v-else>
          <section class="panel-card">
            <div class="panel-card-header">
              <IconBadge icon="i-heroicons-cog-6-tooth" size="sm" bg="var(--ok-soft)" color="var(--ok)" />
              <div>
                <h3 class="panel-card-title">Configuración del Grupo Ocupacional</h3>
                <p class="panel-card-subtitle">Actualiza los datos del grupo ocupacional</p>
              </div>
            </div>

            <div v-if="error" class="banner-error">
              <UIcon name="i-heroicons-exclamation-triangle" class="w-4 h-4 shrink-0" />
              {{ error }}
            </div>

            <GrupoOcupacionalForm :form="form" :errors="errors" show-preview />

            <div class="form-actions">
              <div class="action-group">
                <button class="btn-primary" :disabled="saving" @click="handleSave">
                  <UIcon v-if="saving" name="i-heroicons-arrow-path" class="w-4 h-4 animate-spin" />
                  <UIcon v-else name="i-heroicons-check" class="w-4 h-4" />
                  {{ saving ? 'Guardando...' : 'Guardar Cambios' }}
                </button>
                <NuxtLink :to="`/sigarh/mantenimiento/grupos-ocupacionales?tenant=${tenantId}`" class="btn-cancel">
                  Cancelar
                </NuxtLink>
              </div>
            </div>
          </section>
        </template>
      </div>

      <div class="layout-sidebar">
        <SidebarWidget icon="i-heroicons-document-text" title="Resumen" icon-color="var(--ok)">
          <SummaryList :items="summaryItems">
            <template #estado>
              <StatusBadge :active="form.is_active" variant="mini" />
            </template>
          </SummaryList>
        </SidebarWidget>

        <SidebarWidget icon="i-heroicons-information-circle" title="Información" icon-color="var(--navy)">
          <InfoList :items="infoItems" />
        </SidebarWidget>

        <TipWidget>
          Al editar un grupo ocupacional, verifica que el nombre y código sean coherentes con la clasificación del
          personal.
        </TipWidget>

        <SidebarWidget icon="i-heroicons-chart-bar" title="Estado" icon-color="var(--purple)">
          <StatList :items="statItems" />
        </SidebarWidget>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
definePageMeta({ layout: 'sigarh', middleware: ['auth'] })

const { api } = useApi()
const route = useRoute()
const router = useRouter()

const tenantId = computed(() => (route.query.tenant as string) || '')
const id = computed(() => route.params.id as string)

const loading = ref(true)
const saving = ref(false)
const error = ref('')

const errors = reactive({ nombre: '' })
const form = reactive({ nombre: '', codigo: '', descripcion: '', is_active: true })

const filledFields = computed(() => [form.nombre, form.codigo, form.descripcion].filter(Boolean).length)

const infoItems = [
  'Los grupos ocupacionales clasifican al personal',
  'Se utilizan en la configuración de guardias y permisos',
  'El código interno ayuda a identificar rápidamente',
  'Los grupos inactivos no se pueden asignar',
]

const truncate = (s: string, n: number) => (s ? (s.length > n ? s.slice(0, n) + '...' : s) : '')

const summaryItems = computed(() => [
  { label: 'Nombre', value: form.nombre },
  { label: 'Código', value: form.codigo, mono: true, divider: true },
  { label: 'Descripción', value: truncate(form.descripcion, 50), divider: true },
  { label: 'Estado', slot: 'estado' },
])

const statItems = computed(() => [
  { label: 'Estado actual', value: form.is_active ? 'Activo' : 'Inactivo', color: form.is_active ? 'var(--ok)' : 'var(--ink-soft)' },
  { label: 'Código', value: form.codigo ? '✓ Asignado' : '—', color: form.codigo ? 'var(--teal)' : 'var(--ink-soft)' },
  { label: 'Campos completos', value: `${filledFields.value}/3` },
])

const validateForm = (): boolean => {
  let valid = true
  if (!form.nombre.trim()) {
    errors.nombre = 'El nombre del grupo ocupacional es requerido'
    valid = false
  }
  return valid
}

const handleSave = async () => {
  if (!validateForm()) return

  saving.value = true
  error.value = ''
  try {
    await api(`/sigarh/mantenimiento/grupos-ocupacionales/${id.value}`, {
      method: 'PATCH',
      body: {
        nombre: form.nombre,
        codigo: form.codigo || null,
        descripcion: form.descripcion || null,
        is_active: form.is_active,
      },
    })
    router.push(`/sigarh/mantenimiento/grupos-ocupacionales?tenant=${tenantId.value}`)
  } catch (e: any) {
    error.value = e?.data?.detail || 'No se pudo guardar el grupo ocupacional'
  } finally {
    saving.value = false
  }
}

onMounted(async () => {
  try {
    const data = await api<any>(`/sigarh/mantenimiento/grupos-ocupacionales/${id.value}`)
    form.nombre = data.nombre
    form.codigo = data.codigo || ''
    form.descripcion = data.descripcion || ''
    form.is_active = data.is_active
  } catch (e: any) {
    error.value = e?.data?.detail || 'No se pudo cargar el grupo ocupacional'
  } finally {
    loading.value = false
  }
})
</script>
