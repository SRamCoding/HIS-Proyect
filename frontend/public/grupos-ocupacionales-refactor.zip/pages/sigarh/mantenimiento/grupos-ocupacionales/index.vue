<template>
  <div class="layout-with-sidebar">
    <div class="page-head">
      <div class="page-head-left">
        <IconBadge icon="i-heroicons-user-group" bg="var(--ok-soft)" color="var(--ok)" />
        <div>
          <h1 class="page-head-title">Grupos Ocupacionales</h1>
          <p class="page-head-subtitle">Grupos ocupacionales del personal</p>
        </div>
      </div>
      <NuxtLink :to="`/sigarh/mantenimiento/grupos-ocupacionales/create?tenant=${tenantId}`" class="btn-primary">
        <UIcon name="i-heroicons-plus" class="w-4 h-4" />
        Nuevo Grupo
      </NuxtLink>
    </div>

    <div class="widgets-grid">
      <StatCard icon="i-heroicons-user-group" :value="items.length" label="Total Grupos" accent="var(--ok)" bg="var(--ok-soft)" />
      <StatCard icon="i-heroicons-check-circle" :value="activeItems" label="Activos" accent="var(--teal)" bg="var(--teal-soft)" />
      <StatCard icon="i-heroicons-x-circle" :value="inactiveItems" label="Inactivos" accent="var(--warn)" bg="var(--warn-soft)" />
      <StatCard icon="i-heroicons-barcode" :value="withCode" label="Con Código" accent="var(--purple)" bg="var(--purple-soft)" />
    </div>

    <FilterBar
      :search="search"
      :model-value="activeFilter"
      :filters="filters"
      :result-count="filteredItems.length"
      :show-reset="filteredItems.length < items.length || !!search || activeFilter !== 'all'"
      placeholder="Buscar grupo por nombre o código..."
      @update:search="search = $event"
      @update:model-value="activeFilter = $event"
      @reset="clearFilters"
    />

    <div class="data-table-card">
      <StateBlock v-if="loading" type="loading" message="Cargando grupos ocupacionales..." />

      <StateBlock v-else-if="error" type="error" :message="error">
        <button class="btn-secondary" @click="cargar">Reintentar</button>
      </StateBlock>

      <StateBlock
        v-else-if="filteredItems.length === 0"
        type="empty"
        title="No hay grupos ocupacionales registrados"
        message="Comienza creando un grupo ocupacional"
      >
        <NuxtLink :to="`/sigarh/mantenimiento/grupos-ocupacionales/create?tenant=${tenantId}`" class="btn-primary">
          <UIcon name="i-heroicons-plus" class="w-4 h-4" />
          Nuevo Grupo
        </NuxtLink>
      </StateBlock>

      <div v-else class="data-table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Nombre</th>
              <th>Código</th>
              <th>Descripción</th>
              <th>Estado</th>
              <th style="text-align: right">Acciones</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="item in filteredItems" :key="item.id">
              <td>
                <div class="table-cell-name">
                  <IconBadge
                    icon="i-heroicons-user-group"
                    size="xs"
                    :bg="item.is_active ? 'var(--ok-soft)' : 'var(--mist)'"
                    :color="item.is_active ? 'var(--ok)' : 'var(--ink-soft)'"
                  />
                  <span class="table-cell-name-text">{{ item.nombre }}</span>
                </div>
              </td>
              <td><span class="font-mono-data table-cell-muted">{{ item.codigo || '—' }}</span></td>
              <td><span class="table-cell-muted table-cell-clamp">{{ item.descripcion || '—' }}</span></td>
              <td><StatusBadge :active="item.is_active" variant="table" /></td>
              <td>
                <div class="table-actions">
                  <NuxtLink
                    :to="`/sigarh/mantenimiento/grupos-ocupacionales/${item.id}?tenant=${tenantId}`"
                    class="table-action-btn table-action-btn--edit"
                    title="Editar grupo"
                  >
                    <UIcon name="i-heroicons-pencil-square" class="w-4 h-4" />
                  </NuxtLink>
                  <button class="table-action-btn table-action-btn--delete" title="Eliminar grupo" @click="confirmarEliminar(item)">
                    <UIcon name="i-heroicons-trash" class="w-4 h-4" />
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div v-if="filteredItems.length > 0" class="table-footer">
        <span class="footer-info">
          Mostrando <strong>{{ filteredItems.length }}</strong> de <strong>{{ items.length }}</strong> grupos
          <span v-if="filteredItems.length < items.length">(filtrados)</span>
        </span>
        <button
          v-if="filteredItems.length < items.length || search || activeFilter !== 'all'"
          class="btn-secondary btn-sm"
          @click="clearFilters"
        >
          Limpiar filtros
        </button>
      </div>
    </div>

    <ConfirmModal v-model="showDeleteModal" @confirm="deleteItem">
      ¿Estás seguro de que deseas eliminar el grupo <strong>{{ itemToDelete?.nombre }}</strong>?
      <br />
      <span style="color: var(--ink-soft); font-size: 0.875rem">Esta acción no se puede deshacer.</span>
    </ConfirmModal>
  </div>
</template>

<script setup lang="ts">
definePageMeta({ layout: 'sigarh', middleware: ['auth'] })

interface Item {
  id: string
  nombre: string
  codigo: string | null
  descripcion: string | null
  is_active: boolean
}

const { api } = useApi()
const route = useRoute()

const tenantId = computed(() => (route.query.tenant as string) || '')
const items = ref<Item[]>([])
const loading = ref(true)
const error = ref('')
const search = ref('')
const activeFilter = ref('all')
const showDeleteModal = ref(false)
const itemToDelete = ref<Item | null>(null)

const activeItems = computed(() => items.value.filter((i) => i.is_active).length)
const inactiveItems = computed(() => items.value.filter((i) => !i.is_active).length)
const withCode = computed(() => items.value.filter((i) => i.codigo).length)

const filters = computed(() => [
  { label: 'Todos', value: 'all', count: items.value.length },
  { label: 'Activos', value: 'active', count: activeItems.value },
  { label: 'Inactivos', value: 'inactive', count: inactiveItems.value },
])

const filteredItems = computed(() => {
  let result = items.value

  if (activeFilter.value === 'active') result = result.filter((i) => i.is_active)
  else if (activeFilter.value === 'inactive') result = result.filter((i) => !i.is_active)

  if (search.value.trim()) {
    const q = search.value.toLowerCase().trim()
    result = result.filter((i) => i.nombre.toLowerCase().includes(q) || (i.codigo && i.codigo.toLowerCase().includes(q)))
  }

  return result
})

const clearFilters = () => {
  search.value = ''
  activeFilter.value = 'all'
}

const confirmarEliminar = (item: Item) => {
  itemToDelete.value = item
  showDeleteModal.value = true
}

const deleteItem = async () => {
  if (!itemToDelete.value) return
  try {
    await api(`/sigarh/mantenimiento/grupos-ocupacionales/${itemToDelete.value.id}`, { method: 'DELETE' })
    items.value = items.value.filter((i) => i.id !== itemToDelete.value?.id)
    showDeleteModal.value = false
    itemToDelete.value = null
  } catch (e: any) {
    error.value = e?.data?.detail || 'No se pudo eliminar'
  }
}

const cargar = async () => {
  loading.value = true
  error.value = ''
  try {
    items.value = await api<Item[]>('/sigarh/mantenimiento/grupos-ocupacionales')
  } catch (e: any) {
    error.value = e?.data?.detail || 'Error de conexión'
  } finally {
    loading.value = false
  }
}

onMounted(cargar)
</script>
