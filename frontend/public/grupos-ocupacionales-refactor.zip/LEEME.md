# Refactor a componentes — Grupos Ocupacionales

## Qué cambió
- **13 componentes en `components/ui/`**: piezas genéricas (IconBadge, StatusBadge,
  StatusToggle, FormField, PreviewCard, SidebarWidget, InfoList, TipWidget,
  SummaryList, StatList, StatCard, FilterBar, StateBlock, ConfirmModal).
  Sirven para **cualquier** CRUD futuro (Especialidades, Servicios, etc.), no
  solo Grupos Ocupacionales.
- **1 componente en `components/grupos/`**: `GrupoOcupacionalForm.vue`, los
  campos del formulario (nombre, código, toggle, descripción, preview) que
  antes estaban duplicados al 90% entre `create.vue` y `[id].vue`.
- **3 páginas reescritas**: `index.vue`, `create.vue`, `[id].vue` — mismo
  comportamiento y diseño, muchas menos líneas por página porque delegan el
  markup repetido a los componentes.
- **1 bloque de CSS** (`assets/css/agregar-a-tu-css.css`) para pegar al final
  de tu `app.css`/`main.css` actual.

## Cómo instalarlo
1. Copia la carpeta `components/` dentro de tu carpeta `components/` de Nuxt
   (o mergea si ya tienes archivos ahí). Con Nuxt 3 se auto-importan, no
   necesitas registrarlos.
2. Reemplaza tus 3 archivos actuales de `pages/sigarh/mantenimiento/
   grupos-ocupacionales/` por los de `pages/` de este paquete.
3. Abre `assets/css/agregar-a-tu-css.css` y pega todo su contenido al final
   de tu CSS global (el que tiene `--ink`, `--teal`, etc.). Léelo primero:
   arriba explico el mapeo de colores.

## Sobre los colores que no estaban en tu CSS
Las 3 vistas originales usaban `var(--green)`, `var(--green-soft)`,
`var(--amber)`, `var(--amber-soft)` y sombras `--shadow-sm/md/lg` que no
aparecían en el bloque de CSS que me pasaste. Como tu paleta ya tenía
`--ok`/`--ok-soft` (verde, mismo tono) y `--warn`/`--warn-soft` (ámbar, mismo
tono), reemplacé esas referencias por tus tokens existentes en vez de crear
duplicados. Solo agregué `--purple`/`--purple-soft` (no existía ninguno
parecido) y las sombras/hover que faltaban. Si en tu proyecto real esos
vars sí existen en otro archivo, borra ese bloque `:root` del CSS que te
dejé para no pisar nada.

## Nota de diseño en `GrupoOcupacionalForm.vue`
El componente recibe `form` y `errors` (los mismos objetos `reactive()` del
padre) y los muta directo, igual que hacías en tus vistas originales con
`v-model` sobre `form.nombre`, etc. Es la forma más simple de compartir un
formulario sin escribir un emit por cada campo. Si luego quieres un patrón
más "puro" (unidireccional), se puede migrar a `v-model:nombre`,
`v-model:codigo`, etc. — pero para este caso añade líneas sin más beneficio.

## Resultado
`create.vue` y `[id].vue` bajaron de ~450 líneas de `<style>` cada una a 0
(todo vive en las clases utilitarias compartidas), y el `<template>` de cada
página quedó entre 60–100 líneas en vez de 250+. `index.vue` sigue teniendo
su propia tabla (no vale la pena componentizar una tabla que solo se usa una
vez), pero delega dashboard, filtros, badges, estados y el modal.
